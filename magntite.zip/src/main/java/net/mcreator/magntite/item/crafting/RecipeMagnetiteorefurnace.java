
package net.mcreator.magntite.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.magntite.item.ItemMagnetiteIngot;
import net.mcreator.magntite.block.BlockMagnetiteOre;
import net.mcreator.magntite.ElementsMagntiteMod;

@ElementsMagntiteMod.ModElement.Tag
public class RecipeMagnetiteorefurnace extends ElementsMagntiteMod.ModElement {
	public RecipeMagnetiteorefurnace(ElementsMagntiteMod instance) {
		super(instance, 3);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockMagnetiteOre.block, (int) (1)), new ItemStack(ItemMagnetiteIngot.block, (int) (1)), 1F);
	}
}
