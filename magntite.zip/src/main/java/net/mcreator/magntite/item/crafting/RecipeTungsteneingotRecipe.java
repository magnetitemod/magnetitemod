
package net.mcreator.magntite.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.magntite.item.ItemTungsteneIngot;
import net.mcreator.magntite.block.BlockTungsteneOre;
import net.mcreator.magntite.ElementsMagntiteMod;

@ElementsMagntiteMod.ModElement.Tag
public class RecipeTungsteneingotRecipe extends ElementsMagntiteMod.ModElement {
	public RecipeTungsteneingotRecipe(ElementsMagntiteMod instance) {
		super(instance, 18);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(BlockTungsteneOre.block, (int) (1)), new ItemStack(ItemTungsteneIngot.block, (int) (1)), 0F);
	}
}
