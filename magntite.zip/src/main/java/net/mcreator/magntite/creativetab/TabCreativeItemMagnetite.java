
package net.mcreator.magntite.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.magntite.block.BlockMagnetiteLogo;
import net.mcreator.magntite.ElementsMagntiteMod;

@ElementsMagntiteMod.ModElement.Tag
public class TabCreativeItemMagnetite extends ElementsMagntiteMod.ModElement {
	public TabCreativeItemMagnetite(ElementsMagntiteMod instance) {
		super(instance, 13);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabcreative_item_magnetite") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(BlockMagnetiteLogo.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundImageName("item_search.png");
	}
	public static CreativeTabs tab;
}
