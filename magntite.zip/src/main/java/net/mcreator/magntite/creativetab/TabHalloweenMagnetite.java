
package net.mcreator.magntite.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.magntite.item.ItemHalloween;
import net.mcreator.magntite.ElementsMagntiteMod;

@ElementsMagntiteMod.ModElement.Tag
public class TabHalloweenMagnetite extends ElementsMagntiteMod.ModElement {
	public TabHalloweenMagnetite(ElementsMagntiteMod instance) {
		super(instance, 35);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabhalloween_magnetite") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemHalloween.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static CreativeTabs tab;
}
